#pragma once
#include "treedialog.h"
#include "WordAidKeyStructs.h"
#include "Setting.h"

struct KEYS_USED
{
	UINT nVK;
	CString strSpecKey;
};

enum KEY_TYPE  {KT_NONE, KT_SELECT_WORD, KT_UNDO, KT_SHOWLIST, KT_ABBREV_MANUAL, KT_UNEXPAND_FULL, KT_UNEXPAND_PART,
				KT_ADD_WORD, KT_DELETE_WORD, KT_INSERT, KT_SAY, KT_PAGEUP, KT_PAGEDWN, KT_UPARR, KT_DWNARR, 
				KT_LEFTARR, KT_RIGHTARR,KT_ABBREVBTN/*WA0016 added*/};

class CWordAidTreeDialog :
	public CTreeDialog
{
public:
	CWordAidTreeDialog(CSetting* pSettings);
	~CWordAidTreeDialog(void);

	// Set the keys to be checked.  FALSE if the key is the same as another one
	BOOL SetSelectWordKeys(CString strType, CString strSpecKeys);

	BOOL SetUndoKey(KEYS_USED keys);
	KEY_TYPE SetUndoKey(KEYS_USED keys, BOOL bMessage);

	BOOL SetShowListKey(KEYS_USED keys);
	KEY_TYPE SetShowListKey(KEYS_USED keys, BOOL bMessage);

	BOOL SetAbbrevManualKey(KEYS_USED keys);
	KEY_TYPE SetAbbrevManualKey(KEYS_USED keys, BOOL bMessage);

	BOOL SetUnExpandFullKey(KEYS_USED keys);
	KEY_TYPE SetUnExpandFullKey(KEYS_USED keys, BOOL bMessage);

	BOOL SetUnExpandPartKey(KEYS_USED keys);
	KEY_TYPE SetUnExpandPartKey(KEYS_USED keys, BOOL bMessage);

	KEY_TYPE SetAddWordKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetDeleteWordKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetInsertWordKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetSayWordKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetPageUpKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetPageDownKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetUpArrowKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetDownArrowKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetLeftArrowKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetRightArrowKey(KEYS_USED keys, BOOL bMessage);
	KEY_TYPE SetAbbrevBtnHotkey(KEYS_USED keys,BOOL bMessage);	//WA0016

	// Checks to make sure none of the keys are the same
	BOOL CheckKeySelection(UINT nVK, CString strSpec, KEY_TYPE type);
	KEY_TYPE CheckKeySelection(UINT nVK, CString strSpec, KEY_TYPE type, BOOL bMessage);
private:

	void InitialiseKeys();

	CString GetTypeString(KEY_TYPE type);

	// Hotkeys for setting keys.  The keys are sotred so that
	// they can be checked to make sure that none of the keys
	// are set to the same value.
	KEYS_USED m_SelectWord[MAX_SELECT_KEYS];	
	KEYS_USED m_Undo;
	KEYS_USED m_ShowList;
	KEYS_USED m_AbbrevManual;
	KEYS_USED m_UnExpandFull;
	KEYS_USED m_UnExpandPart;
	KEYS_USED m_AddWord;
	KEYS_USED m_DeleteWord;
	KEYS_USED m_InsertWord;
	KEYS_USED m_SayWord;
	KEYS_USED m_PageUp;
	KEYS_USED m_PageDown;
	KEYS_USED m_UpArrow;
	KEYS_USED m_DownArrow;
	KEYS_USED m_LeftArrow;
	KEYS_USED m_RightArrow;
	KEYS_USED m_AbbrevBtnHK;	//WA0016
	
	CSetting* m_pSettings;		// Store the settings
};
