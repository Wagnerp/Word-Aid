// Wordlist.h: interface for the CWordlist class.
//
//////////////////////////////////////////////////////////////////////////////////////
//																					//
//	WA0002	- changes to allow abbreviation lists to be sorted alphabetically on	//
//			abbreviation															//
//																					//
//////////////////////////////////////////////////////////////////////////////////////
//																					//
//	WA0003 - changes to fix problem with Abbrev dialogue boxes displaying off		//
//			screen.																	//
//																					//
//////////////////////////////////////////////////////////////////////////////////////
//																					//

#if !defined(AFX_WORDLIST_H__9E2F22F6_488B_428F_96F0_1AD33AB64858__INCLUDED_)
#define AFX_WORDLIST_H__9E2F22F6_488B_428F_96F0_1AD33AB64858__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>			// For CArray

#include "AbbrevEditDlg.h"

////////////////////////////////////////////////////////////////////////////////

// list types
#define ABBREV 1
#define ALPHA  2	// default type
#define TOPIC  3

//! define constants  WA0057
#define ETX 0x03  //control-C separator

////////////////////////////////////////////////////////////////////////////////
// deriving from CStringArray allows access to functionality of CStringArray for info about
// and accessing list of words
// a CWordlist is an array of strings, but if it's used for abbreviations it needs to store
// two arrays of words so has CAbbrev member variable
////////////////////////////////////////////////////////////////////////////////

class CWordlist : public CStringArray
{
public:
	void Capitalise(CWordlist& list);
//	CWordlist Capitalise();
	void Capitalise();
	void InitialCapital(CWordlist& list);
//	CWordlist InitialCapital();
	void InitialCapital();
	void ToUpper();		//WA0057 
	void ToLower();		//WA0057 
	CWordlist ToUpper(CString str);
	int m_nNumWords;			// number of words to return after search, default = 0 (all)
	BOOL m_bSorted;				// default = TRUE
	int  m_nType;				// default = ALPHA

	BOOL m_bModified;			// has the wordlist been modified?
	void SetModified(int val = TRUE) {m_bModified = val;};
	
	CWordlist SearchString(CString str); // find all words that contain a string 
	int  SearchWord(CString str);	// find the whole word and return it's position in list
	CWordlist Search(CString str);	// get a list of words that start with this string

	BOOL SaveList(CString filename);
	BOOL LoadWordlist(CString filename, int type);

	int  GetLongest();
	BOOL Empty() { return (GetSize()==0 );}
	void SetNumWords(int num) { m_nNumWords = num;}

	void SortList();
	void EditWord(CString szWord);
	void EditWord(CString old, CString str);
	void Delete(CString str);
	int  Delete(CString str, int max);
	void AddWord(int pos = -1);
	BOOL InsertPos(CString str, int pos);
	BOOL InsertAtStart(CString str);
	BOOL InsertAtEnd(CString str);

	CString GetDDEString();		// WA0057

	CWordlist(int nType = ALPHA);					// create an empty wordlist
	CWordlist(CWordlist& file, int type = 2);	// create a wordlist from another one
	virtual ~CWordlist();
	CWordlist operator = (CWordlist& list);

protected:
	// Minimum length of words to return
	int m_nMinWordLength;
	//! Filename of the Wordlist that is opened
	CString m_strFilename;										// WA0029
public:
	void MergeFiles(CString file1,CString file2);
	// Maximum length of words to return
	int m_nMaxWordLength;
	void SetMinLength(int len) {m_nMinWordLength = len;}
	void SetMaxLength(int len) {m_nMaxWordLength = len;}

	//! Gets the filename of the Wordlist that has been opened
	CString GetFilename()		{return m_strFilename;}			// WA0029
};

////////////////////////////////////////////////////////////////////////////////

class CAbbrevEditDlg;

const CString TXT_CARRIAGE_RETURN		= '\r';
const CString TXT_RETURN_NEWLINE		= "\r\n";
const char CARRIAGE_RETURN			= '\r';
const CString XML_CARRIAGE_RETURN	= _T("<CR>");

const CString SEPERATOR		= _T(" : ");

class CAbbrevList 
{
public:
	CAbbrevList();
	CAbbrevList(CAbbrevList& list, int nType = ABBREV);
	~CAbbrevList();

	CAbbrevList operator = (CAbbrevList& list);

	void MergeFiles(CString file1,CString file2);
	void InsertAtEnd(CString str);
//	void SortList() {m_AbbrevList.SortList();}
	void SortList();										//WA0002
	void EditWord(CString szAbbrev, CString szExpan);
	void EditWord(CString szAbbrevExpan);
	void EditWord(CString oldAbbrev, CString strAbbrev, CString oldExpan, CString strExpan);
	BOOL Delete(CString strAbbrev);
	void AddWord(int pos = -1);
	BOOL InsertPos(CString strAbbrev, CString strExpan, int pos);
	BOOL InsertAtStart(CString strAbbrev, CString strExpan);
	BOOL InsertAtEnd(CString strAbbrev, CString strExpan);

	// Methods to Save and load list
	BOOL SaveList(CString filename);
	BOOL LoadWordlist(CString filename);

	// Search methods
	CWordlist SearchString(CString str);	// find all words that contain a string 
	int  SearchWord(CString str);			// find the whole word and return it's position in list
	CAbbrevList Search(CString str);		// get a list of words that start with this string
	CAbbrevList GetAll();					// Gets all the Abbreviations and returns them as a list

	void SetModified(int val = TRUE) {m_bModified = val;};

	int GetListType() {return m_nType;}

	CString IsAbbrev(CString strAbbrev);	// Get the expansion related to an abbreivation

	// Formatting methods
	static void FormatMultiLine(CString& strText);		// Adds <CR> if multi-lined expansion
	static void FormatMultiLineOutput(CString& strText, CString strType = TXT_CARRIAGE_RETURN);	

	// General List methods
	int GetSize() {return m_AbbrevList.GetSize();}
	CString GetAt(int i) {return m_AbbrevList.GetAt(i) + SEPERATOR + m_arrExpanList.GetAt(i);}
	CString GetExpansionAt(int i) {return m_arrExpanList.GetAt(i);}
	CString GetAbbreviationAt(int i) {return m_AbbrevList.GetAt(i);}
	void SetExpansionAt(CString strExpansion, int nPos) {m_arrExpanList.SetAt(nPos, strExpansion);}
	void SetAbbreviationAt(CString strAbbrev, int nPos) {m_AbbrevList.SetAt(nPos, strAbbrev);}
	void RemoveAll() { m_AbbrevList.RemoveAll(); m_arrExpanList.RemoveAll();}
	BOOL Empty() {return m_AbbrevList.Empty();}

	BOOL m_bModified;							// has the wordlist been modified?
	//WA0047 //CAbbrevEditDlg m_pAbbrevEditDlg;			// Abbrev edit Dialog

	//! Get the filename of the open AbbrevList
	CString GetFilename()			{return m_strFilename;}		// WA0029
private:

	CWordlist m_AbbrevList;					// Store abbreviations
	CStringArray m_arrExpanList;	// Store the abbreviations expansion.
	
	int m_nType;			// Type of list Always ABBREV

	//! Stores the filename of the Open AbbrevList
	CString m_strFilename;									// WA0029

protected:
	//WA0047
	//CRect PositionDialogOffMainWindow(CAbbrevEditDlg& dialog);
};

////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_WORDLIST_H__9E2F22F6_488B_428F_96F0_1AD33AB64858__INCLUDED_)
