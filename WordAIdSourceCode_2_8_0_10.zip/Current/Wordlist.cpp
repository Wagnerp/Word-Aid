// Wordlist.cpp: implementation of the Wordlist classes
//
//////////////////////////////////////////////////////////////////////////
//	CWordlist class
//
//	This class contains the functionality to handle alphabetic and topic
//	lists. It can save and load text files containing wordlists. Text file 
//	layout is one word per line. Sorting is in ascending alphabetic order.
//////////////////////////////////////////////////////////////////////////////////////
//																					//
//	WA0001	- fix problem with sorting in other languages							//
//																					//
//////////////////////////////////////////////////////////////////////////////////////
//																					//
//	WA0002	- changes to allow abbreviation lists to be sorted alphabetically on	//
//			abbreviation															//
//																					//
//////////////////////////////////////////////////////////////////////////////////////
//																					//
//	WA0003 - changes to fix problem with Abbrev dialogue boxes displaying off		//
//			screen.																	//
//																					//
//////////////////////////////////////////////////////////////////////////////////////
//																					//

#include "stdafx.h"

#include "Wordlist.h"
#include "Worddlg.h"
#include "editworddlg.h"
#include "AbbrevEditDlg.h"		// Abbreviation Edit Dialog
#include "WordAid2.h"		

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// create an empty wordlist
CWordlist::CWordlist(int nType /*= ALPHA*/)
{// default is a sorted alphabetic list
	m_nType = nType;
	m_bSorted = TRUE;
	m_nNumWords = 0;
	m_bModified = FALSE;
	m_nMinWordLength = 1;
	m_nMaxWordLength = 10;
	m_strFilename = _T("");				// WA0029
	TRACE("WordList Create\n");
}

////////////////////////////////////////////////////////////////////////////////
// create using another wordlist loaded from file
// where	file = location of the text file containing the list
//			type = type of wordlist, can be ALPHA, TOPIC or ABBREV
////////////////////////////////////////////////////////////////////////////////

CWordlist::CWordlist(CWordlist& file, int type)
{
	//m_nType = type;
	m_nType = file.m_nType;
	if (m_nType == TOPIC)
		m_bSorted = FALSE;
	else
		m_bSorted = TRUE;


	if (m_nType == ABBREV)
		;	// add code here
	else
	{
		for (int i = 0; i < file.GetSize(); i++)
			this->Add(file[i]);
	}

	m_bModified = file.m_bModified;
	m_nNumWords = file.m_nNumWords;
	m_strFilename = file.m_strFilename;		// WA0029
}

////////////////////////////////////////////////////////////////////////////////

CWordlist::~CWordlist()
{
	TRACE("WordList Delete\n");
	RemoveAll();
}

////////////////////////////////////////////////////////////////////////////////

CWordlist CWordlist::operator = (CWordlist& list)
{
	this->RemoveAll();

	for (int i=0; i<list.GetSize(); i++)
		this->Add(list[i]);

	this->m_bModified = list.m_bModified;
	this->m_bSorted = list.m_bSorted;
	this->m_nNumWords = list.m_nNumWords;
	this->m_nType = list.m_nType;
	this->m_strFilename = list.m_strFilename;		//WA0029

	return *this;
}

////////////////////////////////////////////////////////////////////////////////

BOOL CWordlist::InsertAtEnd(CString str)
{
	BOOL done = TRUE;

	if (this->SearchWord(str) != -1)
		//AfxMessageBox(IDS_NO_DUPLICATES,MB_OK);
		done = FALSE;
	else if (!str.IsEmpty())
	{
		Add(str);
		SetModified();
	}
	
	if (m_bSorted)
		SortList();
	

	return done;
}

////////////////////////////////////////////////////////////////////////////////

BOOL CWordlist::InsertAtStart(CString str)
{
	BOOL done = TRUE;

	if (this->SearchWord(str) != -1)
	//	AfxMessageBox(IDS_NO_DUPLICATES,MB_OK);
		done = FALSE;
	else if (!str.IsEmpty())
	{
		InsertPos(str,0);
		SetModified();
	}

	if (m_bSorted)
		SortList();

	return done;
}

////////////////////////////////////////////////////////////////////////////////

BOOL CWordlist::InsertPos(CString str, int pos)
{
	BOOL done = TRUE;

	if (this->SearchWord(str) != -1)
	//	AfxMessageBox(IDS_NO_DUPLICATES,MB_OK);
		done = FALSE;
	else if (!str.IsEmpty())
	{
		this->InsertAt(pos,str);
		SetModified();
	}
	
	if (m_bSorted)
		SortList();
	
	return done;
}

////////////////////////////////////////////////////////////////////////////////
// removes all words that match given string and returns how many removed
// where:	str = the substring to search for
//			num = the maximum number of words to remove
//				default value = -1 which deletes all matches
////////////////////////////////////////////////////////////////////////////////

int CWordlist::Delete(CString str, int max)
{
	int count=0;

	for (int i=0;i<CStringArray::GetSize() || i == max;i++)
	{
		if (GetAt(i).Find(str,0)!= -1)
		{
			CStringArray::RemoveAt(i);
			count++;
			SetModified();
		}
	}
	return count;
}

////////////////////////////////////////////////////////////////////////////////
// delete word 

void CWordlist::Delete(CString str)
{
	int pos = SearchWord(str);
	if (pos != -1)
	{
		CStringArray::RemoveAt(pos);
		SetModified();
	}
	//else
	//	AfxMessageBox(IDS_NOT_FOUND);
}

////////////////////////////////////////////////////////////////////////////////

void CWordlist::SortList()
{
	int n = GetSize();
	int i,k;
	CString temp = _T("");

	for ( k=1;k<n;k++)
	{
		temp = GetAt(k);
		if (temp.IsEmpty())
			;
		else
		{
//WA0001	for (i=k-1;(i>=0) && (temp.Compare(GetAt(i))) <0;i--)
			for (i=k-1;(i>=0) && (temp.Collate(GetAt(i))) <0;i--)
				SetAt(i+1,GetAt(i));
		}
		SetAt(i+1, temp);
		
	}

	for ( k=1;k<n;k++)
	{
		temp = GetAt(k);
		if (temp.IsEmpty())
			;
		else
		{
//WA0001	for (i=k-1;(i>=0) && (temp.CompareNoCase(GetAt(i))) <0;i--)
			for (i=k-1;(i>=0) && (temp.CollateNoCase(GetAt(i))) <0;i--)
				SetAt(i+1,GetAt(i));
		}
		SetAt(i+1, temp);
		
	}

	TRACE("Sorted!!\n");
	m_bSorted = TRUE;
	SetModified();	//WA0002 - ensure prompted to save sorted files
}

////////////////////////////////////////////////////////////////////////////////
// find word, change word, replace word with new version

void CWordlist::EditWord(CString old, CString str)
{
	int pos = this->SearchWord(old);
	if (pos == -1)
	{
		CString str = old;
		str += " not in list";
		AfxMessageBox(str);
	}
	else
	{
		this->RemoveAt(pos);
		InsertPos(str,pos);

		if ((m_nType != ABBREV) && (m_bSorted))
			SortList();

	}
}

////////////////////////////////////////////////////////////////////////////////
// list is saved in text format so can't use serialize

BOOL CWordlist::SaveList(CString filename)
{
    CStdioFile myFile;

	if (myFile.Open(filename,CFile::modeCreate | CFile::modeWrite|CFile::typeText)==0)
	{
		AfxMessageBox(IDS_FILEOPEN_ERROR);
		return FALSE;
	}

	if (m_nType == ABBREV)
		;	// add code here
	else
	{
		for (int i =0;i<GetSize();i++)
		{
			char buf[256];
			CString temp = GetAt(i); 
			strcpy(buf,temp);
			myFile.WriteString(temp);
			myFile.Write("\n",1);
		}
	}

	myFile.Close();

	// Store filename of list 
	m_strFilename = filename;		// WA0029

	SetModified(FALSE);				// WA0038

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////

CString ProcessString(CString str, CString word)
{
	CString temp;


	return temp;
}

////////////////////////////////////////////////////////////////////////////////
// if the string starts with a capital, make all words uppercase
// if not then make all words start with a capital

CWordlist CWordlist::ToUpper(CString str)
{
	CWordlist temp;


	for (int i=0;i<GetSize();i++)
	{
		if (GetAt(i).Left(str.GetLength()).CompareNoCase(str) == 0)
		{
			CString t = GetAt(i);
			if (isupper(str[0]))
				t.MakeUpper();
			else
				t.SetAt(0,toupper(t[0]));

			temp.Add(t);
			TRACE("temp Size = %d\n", temp.GetSize());
		}
	}
	return temp;
}

////////////////////////////////////////////////////////////////////////////////
// search for match at beginning of word - match letters not case
// returns all words that match

CWordlist CWordlist::Search(CString str)
{
	CWordlist temp;

	if (str.IsEmpty())
		return temp;

	for (int i = 0; i<GetSize();i++)
	{
		// does it start with search string?
		if (GetAt(i).Left(str.GetLength()).CompareNoCase(str) == 0)	
		{
			CString t = GetAt(i);
			t.TrimRight();
			// is it within the length requirements?
			if ((t.GetLength() >= m_nMinWordLength) && (t.GetLength() <= m_nMaxWordLength))
				temp.Add(t);// yes, so add it to wordlist to return
			TRACE("temp Size = %d\n", temp.GetSize());
		}
	}
	// should the words start with capital letters?
	if (!str.IsEmpty() && isupper(str[0]))
		InitialCapital(temp);

	return temp;
}

////////////////////////////////////////////////////////////////////////////////
// find a given word and return it's position in list - exact match

int CWordlist::SearchWord(CString str)
{
	CString temp =_T("");
	if (str.IsEmpty())
		return -1;

	for (int i=0;i<GetSize();i++)
	{
		temp = GetAt(i);
		temp.TrimRight();	// remove tab/space at end of word in old lists
		if ( temp == str)
			return i;
	}
	return -1;
}

////////////////////////////////////////////////////////////////////////////////
// find all words that contain a given string

CWordlist CWordlist::SearchString(CString str)
{
	CWordlist temp;
	if (str.IsEmpty())
		return temp;
	
	for (int i = 0; i <GetSize();i++)
	{
		if (GetAt(i).Find(str,0) != -1)
		{
			CString t =GetAt(i);
			t.TrimRight();
			temp.Add(t);
			TRACE("temp Size = %d\n", temp.GetSize());
		}
	}

	return temp;
}

////////////////////////////////////////////////////////////////////////////////

void CWordlist::InitialCapital(CWordlist &list)
{
	for (int i=0;i<list.GetSize(); i++)
	{
		char c = toupper(list.GetAt(i)[0]);	
		list[i].SetAt(0,c);
	}
}

////////////////////////////////////////////////////////////////////////////////

//! Called to make the current wordlist have the initial letter captialised

void CWordlist::InitialCapital()
{
	for (int i=0; i<this->GetSize();i++)
	{
		char c = toupper(this->GetAt(i)[0]);
		CString s = this->GetAt(i);
		s.SetAt(0,c);
		this->SetAt(i,s);
	}

}

////////////////////////////////////////////////////////////////////////////////

void CWordlist::Capitalise(CWordlist &list)
{
	for (int i=0; i<list.GetSize(); i++)
		list[i].MakeUpper();
}

////////////////////////////////////////////////////////////////////////////////

void CWordlist::Capitalise()
{
	for (int i=0; i<this->GetSize(); i++)
	{
		CString t = this->GetAt(i);
		t.MakeUpper();
		this->SetAt(i,t);
	}
}

////////////////////////////////////////////////////////////////////////////////
// return the number of chars in longest word in list

int CWordlist::GetLongest()
{
	int size = 0;
	for (int i=0;i<GetSize();i++)
	{
		if (GetAt(i).GetLength() >size)
			size = GetAt(i).GetLength();
	}

	return size;
}

////////////////////////////////////////////////////////////////////////////////
// read a wordlist from file
// returns false if file not found and true if it is

BOOL CWordlist::LoadWordlist(CString filename, int type)
{
    CStdioFile myFile;
	CString str=_T("");

	RemoveAll();		// Clear the list

	m_nType = type;

	if (m_nType == ABBREV || m_nType == TOPIC)
		m_bSorted = FALSE;
	else
		m_bSorted = TRUE;

	if (myFile.Open(filename,CFile::modeRead|CFile::typeText)==0)
		return FALSE;

	if (m_nType == ABBREV)
		;	// add code here
	else
	{
		do
		{
			myFile.ReadString(str);
			if (!str.IsEmpty())
			{
				str.TrimRight();
				Add(str);
			}
		}
		while (!str.IsEmpty());	// until eof found
	}

	myFile.Close();
	
	// WA0029 - Store the filename
	m_strFilename = filename;

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////

void CWordlist::AddWord(int pos /*= -1*/)
{
	// Add a word to the list
	// WA0050 - Stop dialog from allowing access to the main window
	//CWordDlg dlg(AfxGetMainWnd());
	CWordDlg dlg;

	dlg.wordlist = this;
	dlg.m_nPosInList = pos;
	
	if (dlg.DoModal()==IDOK)
	{
		if (pos == -1)
			InsertAtEnd(dlg.m_editWord);
		else
			InsertPos(dlg.m_editWord,pos);

		// Set modified if there was something to Insert
		if(dlg.m_editWord != _T(""))
		{
			SetModified();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////

void CWordlist::EditWord(CString szWord)
{
	//Edit a word
	CEditWordDlg aDlg(NULL);
	
	szWord.TrimRight();	// remove any whitespace from end of word
	aDlg.m_editWord = szWord;

	if(aDlg.DoModal() == IDOK)
	{
		EditWord(szWord, aDlg.m_editWord);
		SetModified();
	}
}

//! WA0057 - Called to make the wordlist all upper case

void CWordlist::ToUpper()
{
	for (int i=0; i<this->GetSize();i++)
	{
		CString str = this->GetAt(i);
		str.MakeUpper();
		this->SetAt(i,str);
	}
}

//! WA0057 - Called to make the wordlist all lower case

void CWordlist::ToLower()
{
	for (int i=0; i<this->GetSize();i++)
	{
		CString str = this->GetAt(i);
		str.MakeLower();
		this->SetAt(i,str);
	}
}

//! WA0057 - Called to get the Wordlist formated for sending to a DDE client.  This is word|word|
/*!
	\return The wordlist formated for sending to a DDE client
*/

CString CWordlist::GetDDEString()
{
	CString strDDE = _T("");

	for (int i=0;i<GetSize();i++)
	{
		strDDE += GetAt(i);
		strDDE += (char)ETX;
	}

	return strDDE;
}

//////////////////////////////////////////////////////////////////////
// CAbbrevList Class
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAbbrevList::CAbbrevList()
{
	m_AbbrevList.RemoveAll();
	m_arrExpanList.RemoveAll();

	m_nType = ABBREV;
	m_bModified = FALSE;
	m_AbbrevList.m_bSorted = FALSE;		// Make sure list is unsorted

//	m_pAbbrevEditDlg = new CAbbrevEditDlg();

//	ASSERT(m_pAbbrevEditDlg);		// Not created dialog

	//	VERIFY(m_pAbbrevEditDlg.Create(IDD_ADD_EDIT_ABBREV, NULL));	// Dialog not created
//	m_pAbbrevEditDlg = new CAbbrevEditDlg();	WA0031

	TRACE("Abbrev List Create\n");
	m_strFilename = _T("");					// WA0029

}

////////////////////////////////////////////////////////////////////////////////

CAbbrevList::CAbbrevList(CAbbrevList& list, int type)
{
	m_nType = list.m_nType;

	/*if(!m_AbbrevList)
	{
		m_AbbrevList = list.m_AbbrevList;
	}

	if(!m_arrExpanList)
	{
		m_arrExpanList = list.m_arrExpanList;
	}*/

//	if(!m_pAbbrevEditDlg)
	{
//		m_pAbbrevEditDlg = list.m_pAbbrevEditDlg;
	}

/*	m_AbbrevList.m_bSorted = list.m_AbbrevList.m_bSorted;
	
	// Add Abbreviations and expansion to copy
	for (int i = 0; i < list.m_AbbrevList.GetSize(); i++)
	{
		m_AbbrevList.Add(list.m_AbbrevList.GetAt(i));
		m_arrExpanList.Add(list.m_arrExpanList.GetAt(i));
	}
		
		
	m_AbbrevList.m_nNumWords = list.m_AbbrevList.m_nNumWords;


	m_bModified = list.m_bModified;

//	m_pAbbrevEditDlg = new CAbbrevEditDlg();   WA0031

	TRACE("Abbrev List Create\n");
	m_strFilename = list.m_strFilename;				// WA0029
*/
	m_AbbrevList = m_AbbrevList;

	// Add Abbreviations and expansion to copy
	for (int i = 0; i < list.m_AbbrevList.GetSize(); i++)
	{
		m_AbbrevList.Add(list.m_AbbrevList.GetAt(i));
		m_arrExpanList.Add(list.m_arrExpanList.GetAt(i));
		TRACE("AbbrevList Size = %d\n", m_arrExpanList.GetSize());
		TRACE("ExpandList Size = %d\n", m_arrExpanList.GetSize());
	}

	m_bModified = list.m_bModified;
	m_nType = list.m_nType;
	m_strFilename = list.m_strFilename;

}

////////////////////////////////////////////////////////////////////////////////

CAbbrevList::~CAbbrevList()
{
	TRACE("Abbrev List delete\n");
	m_AbbrevList.RemoveAll();
	m_arrExpanList.RemoveAll();
//	delete m_pAbbrevEditDlg;		//WA0047
}

////////////////////////////////////////////////////////////////////////////////

CAbbrevList CAbbrevList::operator = (CAbbrevList& list)
{
	m_arrExpanList.RemoveAll();
	m_AbbrevList.RemoveAll();

	for (int i=0; i<list.m_AbbrevList.GetSize(); i++)
	{
		m_AbbrevList.Add(list.m_AbbrevList.GetAt(i));
		m_arrExpanList.Add(list.m_arrExpanList.GetAt(i));
		TRACE("AbbrevList Size = %d\n", m_arrExpanList.GetSize());
		TRACE("ExpandList Size = %d\n", m_arrExpanList.GetSize());
	}

	this->m_bModified = list.m_bModified;
	m_AbbrevList.m_bSorted = list.m_AbbrevList.m_bSorted;
	m_AbbrevList.m_nNumWords = list.m_AbbrevList.m_nNumWords;
	this->m_nType = list.m_nType;

	this->m_strFilename = list.m_strFilename;		// WA0029

	return *this;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Creates Abbbreviation eidt box and loads the abbreviation and
//				: expansion that is being edited.  If OK clicked it then makes
//				: the changes to the list.
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::EditWord(CString szAbbrev, CString szExpan)
{
	CAbbrevEditDlg aDlg;

	aDlg.SetEditMode();			// Set to edit mode
	aDlg.m_strAbbreviation = szAbbrev;
	FormatMultiLineOutput(szExpan, TXT_RETURN_NEWLINE);
	aDlg.m_strExpansion = szExpan;

	if(aDlg.DoModal() == IDOK)
	{
		// Save if modified
		if(szAbbrev != aDlg.m_strAbbreviation || szExpan != aDlg.m_strExpansion)
		{
			EditWord(szAbbrev, aDlg.m_strAbbreviation, szExpan, aDlg.m_strExpansion);
			SetModified();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Creates Abbbreviation eidt box and loads the abbreviation and
//				: expansion that is being edited.  If OK clicked it then makes
//				: the changes to the list.
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::EditWord(CString szAbbrevExpan)
{
	CString szAbbrev = _T("");
	CString szExpan = _T("");
	CAbbrevEditDlg aDlg;

	// Split Abbreviation and expansion
	int nPos = szAbbrevExpan.Find(SEPERATOR);

	if(nPos != -1)
	{
		szAbbrev = szAbbrevExpan.Left(nPos);
		szAbbrev.TrimLeft();
		szAbbrev.TrimRight();
		szExpan = szAbbrevExpan.Right(szAbbrevExpan.GetLength() - nPos-2);
		szExpan.TrimLeft();
		szExpan.TrimRight();

		aDlg.SetEditMode();			// Set to edit mode
		aDlg.m_strAbbreviation = szAbbrev;
		FormatMultiLineOutput(szExpan, TXT_RETURN_NEWLINE);
		aDlg.m_strExpansion = szExpan;

		if(aDlg.DoModal() == IDOK)
		{
			// Save if modified
			if(szAbbrev != aDlg.m_strAbbreviation || szExpan != aDlg.m_strExpansion)
			{
				EditWord(szAbbrev, aDlg.m_strAbbreviation, szExpan, aDlg.m_strExpansion);
				SetModified();
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Add changes to list
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::EditWord(CString oldAbbrev, CString strAbbrev, 
						   CString oldExpan, CString strExpan)
{
	int nPos = m_AbbrevList.SearchWord(oldAbbrev);

	if(nPos >= 0)
	{
		// Remove
		m_AbbrevList.RemoveAt(nPos);
		m_arrExpanList.RemoveAt(nPos);

		// Add change	
		InsertPos(strAbbrev, strExpan, nPos);

		if (m_AbbrevList.m_bSorted)
		{
			SortList();
		}
	}
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Inserts an eabbreviation and expansion pair at a given 
//				: position.
////////////////////////////////////////////////////////////////////////////////

BOOL CAbbrevList::InsertPos(CString strAbbrev, CString strExpan, int pos)
{
	BOOL bReturn = TRUE;

	// Insert into list
	if(m_AbbrevList.SearchWord(strAbbrev) == -1)
	{
		strAbbrev.TrimLeft();
		strAbbrev.TrimRight();
		strExpan.TrimLeft();
		strExpan.TrimLeft();
		m_AbbrevList.InsertAt(pos, strAbbrev);

		FormatMultiLine(strExpan);				// Format For Mulitline expansions
		m_arrExpanList.InsertAt(pos, strExpan);
		
		if(m_AbbrevList.m_bSorted)
		{
			SortList();
		}

		SetModified();
	}
	else	// Already in the list
	{
		bReturn = FALSE;
	}
	
	return bReturn;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Displays the Abbreviation Edit Diaolg so that abbreviation
//				: and expansions can be added to the list.
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::AddWord(int pos /*= -1*/)
{
//	if (!m_pAbbrevEditDlg->m_hWnd)
//	{
//		VERIFY(m_pAbbrevEditDlg->Create(IDD_ADD_EDIT_ABBREV, NULL));	// Dialog not created
//	}
	// WA0047
	CAbbrevEditDlg aDlg;
	//if(m_pAbbrevEditDlg)
	//{
		// Make the main window stary active when adding abbreviations
		CWordAid2App* pApp = (CWordAid2App*)AfxGetApp();
		CWordAid2Dlg* pWordAidDlg = pApp->GetWordAidWindow();
		pWordAidDlg->StayActive();

		// Move window off main application window
//		PositionDialogOffMainWindow(&aDlg);		// WA0047

		// Give list to add abbreviation to
		aDlg.SetAbbviationList(this);		//WA0031

		//aDlg.ShowWindow(SW_SHOW);
	//	aDlg.m_bVisible = TRUE;	//WA0003

		aDlg.DoModal();

		pWordAidDlg->StayActive(FALSE);

//	}
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Moves the dialog so that it is displayed off an applications
//				: main window.  It first tries to display it above the window 
//				: if there is room; otherwise it displays it below.
//
// PARAMETERS	: dialog - dialog to move off main application.
//				:
// RETURNS		: The new dialog rectangle if successful; otherwise an empty
//				: CRect(0,0,0,0)
////////////////////////////////////////////////////////////////////////////////

//WA0047
/*CRect CAbbrevList::PositionDialogOffMainWindow(CAbbrevEditDlg& dialog)
{
	CWordAid2App* pApp = (CWordAid2App*)AfxGetApp();
	
	CWnd* pMainWnd = AfxGetMainWnd();

	CRect rectMain,
		  rectDlg,
		  rectRet;
	
	// Get Screen position for main window and the dialog
	CWordAid2Dlg* pWordAidDlg = pApp->GetWordAidWindow();
	pWordAidDlg->GetWindowRect(rectMain);

	//pMainWnd->GetWindowRect(rectMain);
	dialog.GetWindowRect(rectDlg);

	// Get Height of Screen
	int nScreenY = GetSystemMetrics(SM_CYSCREEN);

	// Can Dialog be shown Above main window
	int nMainTop = rectMain.top;
	int nDialogHeight = rectDlg.Height();

//WA0003	if(nMainTop + nDialogHeight < nScreenY)		// Above window
	if(nMainTop - nDialogHeight > 10)		// Above window	//WA0003
	{
		rectRet = CRect(rectDlg.left, rectMain.top - rectDlg.Height(), rectDlg.right, rectMain.top);
		dialog.MoveWindow(rectRet.left, rectRet.top, rectRet.Width(), rectRet.Height(), TRUE);//rectRet);
	}
//WA0003else	// Below Window
	else if (rectMain.bottom + nDialogHeight < (nScreenY-20))	// Below Window	//WA0003
	{
//WA0003rectRet = CRect(rectDlg.left, rectMain.bottom, rectDlg.right, rectMain.bottom - rectDlg.Height());	//WA0003
		rectRet = CRect(rectDlg.left, rectMain.bottom, rectDlg.right, rectMain.bottom + rectDlg.Height());
		dialog.MoveWindow(rectRet.left, rectRet.top, rectRet.Width(), rectRet.Height(), TRUE);
	}
	else							//WA0003
		dialog.MoveWindow(0,0);	//WA0003

	return rectRet;
}*/

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Inserts to the end of the abbreviation list.
////////////////////////////////////////////////////////////////////////////////

BOOL CAbbrevList::InsertAtEnd(CString strAbbrev, CString strExpan)
{
	BOOL bReturn = TRUE;

	strAbbrev.TrimLeft();
	strAbbrev.TrimRight();
	strExpan.TrimLeft();
	strExpan.TrimRight();

	m_AbbrevList.Add(strAbbrev);
	TRACE("AbbrevList Size = %d\n", m_arrExpanList.GetSize());

	FormatMultiLine(strExpan);
	m_arrExpanList.Add(strExpan);
	TRACE("ExpandList Size = %d\n", m_arrExpanList.GetSize());

	if(m_AbbrevList.m_bSorted)
	{
		SortList();
	}

	SetModified();

	return bReturn;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Sorts the list by abbreviation
//
// PARAMETERS	: none
//
// RETURNS		: nothing
//
// ADDED for WA0002
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::SortList()
{
	int n = GetSize();
	int i,k;
	CString strAbbrev = _T("");
	CString strExpansion = _T("");

	for ( k=1;k<n;k++)
	{
		strAbbrev = m_AbbrevList.GetAt(k);
		strExpansion = m_arrExpanList.GetAt(k);
		if (strAbbrev.IsEmpty())
			;
		else
		{
//WA0001	for (i=k-1;(i>=0) && (temp.Compare(GetAt(i))) <0;i--)
			for (i=k-1;(i>=0) && (strAbbrev.Collate(m_AbbrevList.GetAt(i))) <0;i--)
			{
				m_AbbrevList.SetAt(i+1,m_AbbrevList.GetAt(i));
				m_arrExpanList.SetAt(i+1,m_arrExpanList.GetAt(i));
			}
		}
		m_AbbrevList.SetAt(i+1, strAbbrev);
		m_arrExpanList.SetAt(i+1,strExpansion);
		
	}

	for ( k=1;k<n;k++)
	{
		strAbbrev = m_AbbrevList.GetAt(k);
		strExpansion = m_arrExpanList.GetAt(k);
		if (strAbbrev.IsEmpty())
			;
		else
		{
//WA0001	for (i=k-1;(i>=0) && (temp.CompareNoCase(GetAt(i))) <0;i--)
			for (i=k-1;(i>=0) && (strAbbrev.CollateNoCase(m_AbbrevList.GetAt(i))) <0;i--)
			{
				m_AbbrevList.SetAt(i+1,GetAt(i));
				m_arrExpanList.SetAt(i+1,m_arrExpanList.GetAt(i));
			}
		}
		m_AbbrevList.SetAt(i+1, strAbbrev);
		m_arrExpanList.SetAt(i+1,strExpansion);
	}

	TRACE("Sorted!!\n");


	m_AbbrevList.m_bSorted = TRUE;
	SetModified();
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Saves the Abbreviation to a text file.
//
// PARAMETERS	: filename - filename to save file as.
//
// RETURNS		: TRUE if the list was succesfully saved.
////////////////////////////////////////////////////////////////////////////////

BOOL CAbbrevList::SaveList(CString filename)
{
	CStdioFile myFile;

	TRY
	{
		if (myFile.Open(filename,CFile::modeCreate | CFile::modeWrite|CFile::typeText)==0)
		{
			AfxMessageBox("Couldn't open file");
			return FALSE;
		}

		for(int i = 0; i < m_AbbrevList.GetSize(); i++)
		{
			char buf[256];
			CString strText = GetAt(i);
			strcpy(buf, strText);
			myFile.WriteString(strText);
			myFile.Write("\n", 1);
		}
		
		SetModified(FALSE);  // WA0038

		myFile.Close();
	}
	CATCH(CFileException, e)
	{
		// TODO : Get Exception to Display
		//::MessageBox(NULL, e.m_cause, MB_OK|MB_ICONEXCLAMATION);
		myFile.Close();
		return FALSE;
	}
	END_CATCH
	
	// WA0029 - Store the filename
	m_strFilename = filename;

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Loads the abbreviation list into the CAbbrevList.
//
// PARAMETERS	: filename - File to open.
//
// RETURNS		: TRUE if the file wa successfully loaded.
////////////////////////////////////////////////////////////////////////////////

BOOL CAbbrevList::LoadWordlist(CString filename)
{
	// Just return if the filename is empty
	if(filename.IsEmpty())
	{
		return FALSE;
	}

	this->RemoveAll();

	CStdioFile myFile;
	CString str=_T("");
	int nPos = 0;

	m_AbbrevList.RemoveAll();		// Clear the list

	m_nType = ABBREV;
	m_AbbrevList.m_bSorted = FALSE;

	TRY
	{
		if (myFile.Open(filename,CFile::modeRead|CFile::typeText)==0)
		{
			CString strError = _T("");

			// Display Error Message
			strError.LoadString(IDS_ERROR_LOADING_FILE);
			strError+= filename;
			AfxMessageBox(strError, MB_OK|MB_ICONEXCLAMATION);
			return FALSE;
		}

		do
		{
			myFile.ReadString(str);
			if(!str.IsEmpty())
			{
				str.TrimRight();
				
				nPos = str.Find(SEPERATOR);

				if(nPos != -1)
				{
					m_AbbrevList.Add(str.Left(nPos));
					TRACE("AbbrevList Size = %d\n", m_arrExpanList.GetSize());
					str = str.Right(str.GetLength() - nPos-2);
					str.TrimLeft();
					m_arrExpanList.Add(str);
					TRACE("ExpandList Size = %d\n", m_arrExpanList.GetSize());
				}
			}
		}
		while(!str.IsEmpty());

		myFile.Close();
	}
	CATCH(CFileException, e)
	{
		// TODO : Get Exception to Display
		//::MessageBox(m_hWwd, e.cause, MB_OK|MB_ICONEXCLAMATION);
		myFile.Close();
		return FALSE;
	}
	END_CATCH

	// WA0029 - Store the filename
	m_strFilename = filename;

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Deletes an abbreviation and expansion from the abbrev list.
//
// PARAMETERS	: strAbbrev - Abbrev and expansion string to delete from list
//
// RETURNS		: TRUE if the Abbreviation and expansion are deleted from the
//				: list.
////////////////////////////////////////////////////////////////////////////////

BOOL CAbbrevList::Delete(CString strAbbrev)
{
	BOOL bReturn = FALSE;
	CString strFindAbbrev = _T("");
	CString strMessage = _T("");

	strMessage.LoadString(IDS_DELETE_ABBREV);

	// Make sure user wants to remove abbreviation
	if(AfxMessageBox(strMessage, MB_YESNO|MB_ICONQUESTION) == IDYES)
	{
		// Get the Abbreviation
		int nPos = strAbbrev.Find(SEPERATOR);
		strFindAbbrev = strAbbrev.Left(nPos);

		for(int i = 0; i < GetSize(); i++)
		{
			// If abbreviation is found remove the abbreviation and expansion
			if(m_AbbrevList.GetAt(i).Find(strFindAbbrev) != -1)
			{
				m_AbbrevList.RemoveAt(i);
				m_arrExpanList.RemoveAt(i);
				bReturn = TRUE;
				m_bModified = TRUE;
				break;
			}
		}
	}

	return bReturn;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Searchs the Abbreviation list and returns the Abbreviations
//				: and expansions that contain from the start the search string.
//
// PARAMETERS	: str - Search String.
//
// RETURNS		: A list of Abbreivations that begin with the search string.
////////////////////////////////////////////////////////////////////////////////

CAbbrevList CAbbrevList::Search(CString str)
{
	CAbbrevList temp;

	if (str.IsEmpty())
		return temp;

	for (int i = 0; i < m_AbbrevList.GetSize();i++)
	{
		// does it start with search string?
		if (GetAt(i).Left(str.GetLength()).CompareNoCase(str) == 0)	
		{
			CString strAbbrev = GetAt(i);
			strAbbrev.TrimRight();
			temp.InsertAtEnd(m_AbbrevList.GetAt(i), m_arrExpanList.GetAt(i));
		}
	}

	return temp;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Checks to see if an Abbreviation exists in the list.
//
// PARAMETERS	: strAbbrev - Abbreviation to check.
//
// RETURNS		: The expansion related to the abbreviation if one exisits;
//				: otherwise empty string.
////////////////////////////////////////////////////////////////////////////////

CString CAbbrevList::IsAbbrev(CString strAbbrev)
{
	CString strReturn = _T("");

	if(!strAbbrev.IsEmpty())
	{
		for (int i = 0; i < m_AbbrevList.GetSize();i++)
		{
			// does it start with search string?
			if (m_AbbrevList.GetAt(i).CompareNoCase(strAbbrev) == 0)	
			{
				strReturn = m_arrExpanList.GetAt(i);
				break;	
			}
		}
	}
	
	return strReturn;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Returns all the Abbreviations in the list.  This function
//				: was created becuase of the problems with the copy constructor
//				: and equals with pointers.
//
// RETURNS		: List with all the abbreviations in.
////////////////////////////////////////////////////////////////////////////////

CAbbrevList CAbbrevList::GetAll()
{
	CAbbrevList list;

	for(int i = 0; i < m_AbbrevList.GetSize(); i++)
	{
		list.InsertAtEnd(m_AbbrevList.GetAt(i), m_arrExpanList.GetAt(i));
	}

	return list;
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Takes a string a checks to see if there are any carriage 
//				: returns in it.  If there is it assumes that after the carriage
//				: return there is a new line operator.  These are removed and
//				: replaced by <CR>.
//
// PARAMETERS	: strText - string to convert carriage returns.
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::FormatMultiLine(CString& strText)
{
	BOOL bMultiLine = FALSE;		// Set to true if the string is multilined
	CString strTemp = _T("");
	int nPos = 0;


	for(int i = 0; i < strText.GetLength(); i++)
	{
		if(strText.GetAt(i) == CARRIAGE_RETURN)
		{
			bMultiLine = TRUE;

			
			strTemp += strText.Left(i);
			strTemp += XML_CARRIAGE_RETURN;
			strText = strText.Right(strText.GetLength() - i - 2);
			//WA0040 - Reset count to -1 as the for loop increase the count by one so to get 0 use -1
			i = -1;
			//i = 0;		// Reset count
			
		}
	}

	if(bMultiLine)
	{
		strTemp += strText;
		strText =strTemp;
	}
}

////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Takes a string that has been formated with <CR> and replaces
//				: them with the '\r\n' combination to represent a newline.
//
// PARAMETERS	: strText - string to convert <CR> to '\r\n'.
//				: strType - The character to replace the <CR> with. Choice of
//				: TXT_CARRIAGE_RETURN or TXT_RETURN_NEWLINE
////////////////////////////////////////////////////////////////////////////////

void CAbbrevList::FormatMultiLineOutput(CString& strText, 
										CString strType /*= TXT_CARRIAGE_RETURN*/)
{
	// Make sure valid type entered
	ASSERT(strType != TXT_CARRIAGE_RETURN || strType != TXT_RETURN_NEWLINE);

	BOOL bMultiLine = FALSE;
	CString strTmp = strText;
	int nPos = 0;

	strText = _T("");	// Empty text

	while((nPos = strTmp.Find(XML_CARRIAGE_RETURN)) != -1)
	{
		bMultiLine = TRUE;

		strText += strTmp.Left(nPos);
		strText += strType;

		strTmp = strTmp.Right(strTmp.GetLength() - nPos - XML_CARRIAGE_RETURN.GetLength());
	}

		strText += strTmp;		// Add text
}
// needs to split string into two bits then add it to this list
void CAbbrevList::InsertAtEnd(CString str)
{

}
// clears wordlist and loads first file into this list
// loads second file and adds words to this list. checking they don't already exist
// sorts the completed list if necessary
void CWordlist::MergeFiles(CString file1, CString file2)
{
	CWordlist list2;

	if (m_nType == ALPHA)
	{
		this->RemoveAll();
		this->LoadWordlist(file1,ALPHA);

		list2.LoadWordlist(file2,ALPHA);
		
		for (int i=0; i < list2.GetSize();i++)
		{
			if (this->SearchWord(list2.GetAt(i)) == -1)
				this->Add(list2.GetAt(i));
		}

		this->SortList();
	}
	if (m_nType == TOPIC)
	{
		this->RemoveAll();
		this->LoadWordlist(file1,TOPIC);
		list2.LoadWordlist(file2,TOPIC);

		for (int i=0; i < list2.GetSize();i++)
		{
			if (this->SearchWord(list2.GetAt(i)) == -1)
				this->Add(list2.GetAt(i));
		}

		if (m_bSorted)
			this->SortList();
	}
}

void CAbbrevList::MergeFiles(CString file1, CString file2)
{
	CAbbrevList list2;

	this->RemoveAll();
	this->LoadWordlist(file1);
	list2.LoadWordlist(file2);

	for (int i=0;i<list2.GetSize();i++)
	{
		if (!(this->IsAbbrev(list2.GetAbbreviationAt(i))).IsEmpty())
			this->InsertAtEnd(list2.GetAbbreviationAt(i),list2.GetExpansionAt(i));
	}
}
