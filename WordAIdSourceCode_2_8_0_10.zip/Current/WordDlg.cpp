// WordDlg.cpp : implementation file
//

#include "stdafx.h"
//#include "Word Aid 2Dlg.h"
#include "WordDlg.h"
#include "WordAid2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWordDlg dialog


CWordDlg::CWordDlg(CWnd* pParent /*=NULL*/, BOOL bAddMode /*= TRUE*/)
	: CDialog(CWordDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWordDlg)
	m_editWord = _T("");
	//}}AFX_DATA_INIT
	m_bAddMode = bAddMode;
	m_nPosInList = -1;
//	m_ctrlSpeaker = NULL;
}

CWordDlg::~CWordDlg()
{
	if (m_ctrlSpeaker)
		m_ctrlSpeaker.DestroyWindow();
}


void CWordDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWordDlg)
	DDX_Text(pDX, IDC_EDIT1, m_editWord);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_BTN_SAY, m_btnSay);
	DDX_Control(pDX, IDC_BTN_LEXICON, m_btnLexicon);
}


BEGIN_MESSAGE_MAP(CWordDlg, CDialog)
	//{{AFX_MSG_MAP(CWordDlg)
	ON_BN_CLICKED(IDC_BTN_IDOK, OnBtnIdok)
	ON_BN_CLICKED(IDC_BTN_ADDWORD, OnBtnAddword)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_SAY, OnBtnClickSay)
	ON_BN_CLICKED(IDC_BTN_LEXICON, OnBtnClickLexicon)
	ON_EN_CHANGE(IDC_EDIT1, OnEditChangeWord)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWordDlg message handlers

BOOL CWordDlg::OnInitDialog()
{
	CString szTitle = _T("");

	CDialog::OnInitDialog();

	m_ctrlSpeaker.Create("Speaker",WS_CHILD,CRect(0,0,1,1),this,2);

	
	// Disable if no speech present
	m_btnSay.EnableWindow(FALSE);
	m_btnLexicon.EnableWindow(FALSE);
	
/*	if(m_bAddMode)
	{
		szTitle.LoadString(IDS_WORD_ADD);	
	}
	else
	{
		szTitle.LoadString(IDS_WORD_EDIT);
	}

	SetWindowText(szTitle);
*/
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWordDlg::OnOK()
{
	TRACE("in ok func\\n");
	CEdit* box = (CEdit*)GetDlgItem(IDC_EDIT1);
	CString word = _T("");

	box->GetWindowText(word);

//	if (!m_bAddMode)	//check we're adding not editing word
//		OnBtnIdok();
//	else
//	{
		BOOL done = TRUE;

		if (m_nPosInList == -1)
			done = wordlist->InsertAtEnd(word);
		else
			done = wordlist->InsertPos(word,m_nPosInList);
		if (!done)
			AfxMessageBox(IDS_NO_DUPLICATES,MB_OK);

		box->SetWindowText("");
		
		CWordAid2Dlg* dlg = ((CWordAid2App*)AfxGetApp())->m_pWordAid;

		if (wordlist->m_nType == TOPIC)
		{
			dlg->DisplayTopicList();
	//		dlg->Invalidate();
		}
		if (wordlist->m_nType == ALPHA)
		{
			dlg->DisplayAlphaList();
		//	dlg->Invalidate();
		}
//	}
}

void CWordDlg::OnBtnIdok() 
{
	// TODO: Add your control notification handler code here
	TRACE("in my ok function\\n");

	CEdit* box = (CEdit*)GetDlgItem(IDC_EDIT1);
	CString word = _T("");

	box->GetWindowText(word);

	if (!word.IsEmpty())
	{
		BOOL done = TRUE;

		if (m_nPosInList == -1)
			done = wordlist->InsertAtEnd(word);
		else
			done = wordlist->InsertPos(word,m_nPosInList);
		if (!done)
			AfxMessageBox(IDS_NO_DUPLICATES,MB_OK);
	}

	CDialog::OnOK();
}

void CWordDlg::OnBtnAddword() 
{
	// TODO: Add your control notification handler code here
	OnOK();
}

void CWordDlg::OnBtnClickSay()
{
	UpdateData(TRUE);

	m_ctrlSpeaker.Speak(m_editWord);
}

void CWordDlg::OnBtnClickLexicon()
{
	m_ctrlSpeaker.ShowLexiconDialog((long)m_hWnd);
}

void CWordDlg::OnEditChangeWord()
{
	UpdateData(TRUE);

	if(m_editWord != _T(""))
	{
		if(m_ctrlSpeaker)
		{
			// Enable if text
			m_btnSay.EnableWindow(TRUE);
			m_btnLexicon.EnableWindow(TRUE);
		}
	}
	else
	{
		if(m_ctrlSpeaker)
		{
			// Disable if no text
			m_btnSay.EnableWindow(FALSE);
			m_btnLexicon.EnableWindow(FALSE);
		}
	}	

}

