#if !defined(AFX_WORDDLG_H__6F0E505E_109E_4EEE_81EB_1236FFD523C0__INCLUDED_)
#define AFX_WORDDLG_H__6F0E505E_109E_4EEE_81EB_1236FFD523C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WordDlg.h : header file
//
#include "resource.h"
#include "Word Aid 2Dlg.h"
#include "Wordlist.h"
/////////////////////////////////////////////////////////////////////////////
// CWordDlg dialog - class to handle adding word to a wordlist

class CWordDlg : public CDialog
{
// Construction
public:
	CWordDlg(CWnd* pParent = NULL, BOOL bAddMode = TRUE);   // standard constructor
	~CWordDlg();

	virtual void OnOK();
	CWordlist* wordlist;
	int m_nPosInList;
// Dialog Data
	//{{AFX_DATA(CWordDlg)
	enum { IDD = IDD_ADDWORD_DLG };
	CString	m_editWord;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL m_bAddMode;		// TRUE if adding a word

	CTextSpeaker m_ctrlSpeaker;		// Text Speaker for lexicon

	// Controls
	CButton m_btnSay;
	CButton m_btnLexicon;

	// Generated message map functions
	//{{AFX_MSG(CWordDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnIdok();
	afx_msg void OnBtnAddword();
	//}}AFX_MSG
	afx_msg void OnBtnClickSay();
	afx_msg void OnBtnClickLexicon();
	afx_msg void OnEditChangeWord();

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WORDDLG_H__6F0E505E_109E_4EEE_81EB_1236FFD523C0__INCLUDED_)
