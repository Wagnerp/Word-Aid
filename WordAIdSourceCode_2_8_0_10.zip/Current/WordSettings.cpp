// PopupSettings.cpp : implementation file
//

#include "stdafx.h"
#include "WordAid2.h"
#include "WordSettings.h"

#include "SettingIndex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: CALLBACK function to display the fonts in a control.	   //
/////////////////////////////////////////////////////////////////////////////

int CALLBACK EnumFontFamiliesExProcWord(ENUMLOGFONTEX *lpelfe,
									NEWTEXTMETRICEX *lpntme,
									int FontType,
									LPARAM lParam)
{
	// Make sure blanks are not added
	CString szText = (LPSTR)(lpelfe->elfFullName);
	if(!szText.IsEmpty())
	{
		// Add font to combo box
		if(::SendMessage((HWND)lParam, CB_FINDSTRING, 0,
					  (LONG)(LPSTR)(lpelfe->elfFullName)) == LB_ERR)
		{
			::SendMessage((HWND)lParam, CB_ADDSTRING, 0,
						 (LONG)(LPSTR)(lpelfe->elfFullName));
		}
	}

    return 1;
}

/////////////////////////////////////////////////////////////////////////////
// CWordSettings dialog

CWordSettings::CWordSettings(CWnd* pParent /*=NULL*/)
	: CTreePage(CWordSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWordSettings)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_bModified = FALSE;
}

CWordSettings::~CWordSettings()
{
//	m_pPopup->DestroyWindow();
//	delete m_pPopup;
}

void CWordSettings::DoDataExchange(CDataExchange* pDX)
{
	CTreePage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWordSettings)
	DDX_Control(pDX, IDC_CMB_FONT_COLOUR, m_cmb_font_colour);
	DDX_Control(pDX, IDC_CMB_COLOUR, m_cmb_back_colour);
	DDX_Control(pDX, IDC_CMB_FONT_SIZES, m_cmb_font_sizes);
	DDX_Control(pDX, IDC_CMB_FONT_NAME, m_cmb_font_name);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_BTN_CUSTOM_COLOUR, m_btn_custom_back_colour);
	DDX_Control(pDX, IDC_BTN_CUSTOM_FONT_COLOUR, m_btn_custom_font_colour);
	DDX_Control(pDX, IDC_CMB_HIGHLIGHT_COLOUR, m_cmb_highlight_colour);
}


BEGIN_MESSAGE_MAP(CWordSettings, CTreePage)
	//{{AFX_MSG_MAP(CWordSettings)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_CUSTOM_COLOUR, OnBnClickedBtnCustomColour)
	ON_BN_CLICKED(IDC_BTN_CUSTOM_FONT_COLOUR, OnBnClickedBtnCustomFontColour)
	ON_CBN_SELCHANGE(IDC_CMB_COLOUR, OnCbnSelchangeCmbColour)
	ON_CBN_SELCHANGE(IDC_CMB_FONT_NAME, OnCbnSelchangeCmbFontName)
	ON_CBN_SELCHANGE(IDC_CMB_FONT_COLOUR, OnCbnSelchangeCmbFontColour)	ON_CBN_SELCHANGE(IDC_CMB_FONT_SIZES, OnCbnSelchangeCmbFontSizes)
	ON_BN_CLICKED(IDC_BTN_CUSTOM_HIGHLIGHT_COLOUR, OnBnClickedBtnCustomHighlightColour)
	ON_CBN_SELCHANGE(IDC_CMB_HIGHLIGHT_COLOUR, OnCbnSelchangeCmbHighlightColour)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWordSettings message handlers

BOOL CWordSettings::OnInitDialog() 
{
	CString szComboText = _T("");
	int nIndex = 0;

	CTreePage::OnInitDialog();

	// Create the child window
//	m_pPopup = new CChildWnd();

//	ASSERT(m_pPopup);		// Check the pointer is valid
//	m_pPopup->m_pSettings = m_Settings;

//		if(!m_pPopup->Create(this->m_hWnd))
//	{
//#ifdef _DEBUG
//		AfxMessageBox(_T("Popup Failed to load"));
//#endif
//	}

//		CWordlist list;
//		list.Add("Word 1");
//		list.Add("Word 2");
//		m_pPopup->SetWordlistT(list);

//	m_pPopup->ShowWindow(SW_SHOW);

	FillFontCombo();

	FillFontSizesCombo();
	
	// Initialise the settings from registry
	InitialiseSettings();		

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Call to fill the font name combobox with all the		   //
//				: fonts on the system.									   //
//				:														   //
// RETURNS		: TRUE if it was successful.							   //
/////////////////////////////////////////////////////////////////////////////

BOOL CWordSettings::FillFontCombo()
{
	BOOL bReturn = TRUE;

    HDC hDC = ::GetDC(NULL);

    LOGFONT lf = { 0, 0, 0, 0, 0, 0, 0, 0, DEFAULT_CHARSET, 0, 0, 0,
				   0, "" };

	EnumFontFamiliesEx( hDC, &lf, (FONTENUMPROC)EnumFontFamiliesExProcWord, (long)m_cmb_font_name.m_hWnd, 0 );

    ::ReleaseDC( NULL, hDC );
  
	return bReturn;
} 
/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Fill the combobox with the font size.					   //
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::FillFontSizesCombo()
{
	CString szComboText = _T("");

	TRY
	{
		// Load Combo Strings
		szComboText.LoadString(IDS_FONT_SIZES);
		
		FillCombo(m_cmb_font_sizes, szComboText);
	}
	CATCH(CMemoryException, e)
    {
    }
    END_CATCH

}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Call to fill a combobox with a structured strig with '|' //
//				: as a seperator.										   //
//				:														   //
// PARAMETERS	: combo - combobox to fill.								   //
//				: szComboBox - string to fill combobox with.			   //
/////////////////////////////////////////////////////////////////////////////
void CWordSettings::FillCombo(CComboBox& combo, CString szComboText)
{
	int nSplitPos = 0;

	// Add each item to the combo box
	for(nSplitPos = szComboText.Find(_T("|")); nSplitPos != -1; nSplitPos = szComboText.Find(_T("|")))
	{
		combo.AddString(szComboText.Left(nSplitPos));
		szComboText = szComboText.Right(szComboText.GetLength() - nSplitPos-1);
	}
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::InitialiseSettings()
{
	 SetButtonSettings();
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::SetButtonSettings()
{
	ClearSettings();

	m_cmb_back_colour.SetSelectedColorValue(m_Settings->GetColourSetting(LABEL_BACKGROUND));
	m_cmb_font_name.SelectString(0, m_Settings->GetSetting(LABEL_FONT_NAME));
	m_cmb_font_colour.SetSelectedColorValue(m_Settings->GetColourSetting(LABEL_FOREGROUND));
	m_cmb_font_sizes.SelectString(-1, m_Settings->GetSetting(LABEL_FONT_SIZE));
	m_cmb_highlight_colour.SetSelectedColorValue(m_Settings->GetColourSetting(HIGHLIGHT_COLOUR));
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::OnBnClickedBtnCustomColour()
{
	CColorDialog aDlg;
/*	if (m_cmb_back_colour.GetCurSel() == 16)
	{	COLORREF white = RGB(255,255,255);
		for (int i =0;i<16;i++)
		{
			if (aDlg.m_cc.lpCustColors[i] == white)
			{
				aDlg.m_cc.lpCustColors[i] = m_Settings->GetColourSetting(LABEL_BACKGROUND);
				i= 16;
			}
		}
	}
*/	if(aDlg.DoModal() == IDOK)
	{
		// TODO : Add String to string table
		// Add the colour and set it to be current selection
		COLORREF colour = aDlg.GetColor();
		int nIndex = m_cmb_back_colour.AddColor(_T("Custom"), colour);
		m_cmb_back_colour.SetCurSel(nIndex);
		SetModified();
	}
	
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::OnBnClickedBtnCustomFontColour()
{
	CColorDialog aDlg;
/*	if (m_cmb_font_colour.GetCurSel() == 16)
	{	COLORREF white = RGB(255,255,255);
		for (int i =0;i<16;i++)
		{
			if (aDlg.m_cc.lpCustColors[i] == white)
			{
				aDlg.m_cc.lpCustColors[i] = m_Settings->GetColourSetting(LABEL_BACKGROUND);
				i= 16;
			}
		}
	}
*/
	if(aDlg.DoModal() == IDOK)
	{
		// TODO : Add String to string table
		// Add the colour and set it to be current selection
		COLORREF colour = aDlg.GetColor();
		int nIndex = m_cmb_font_colour.AddColor(_T("Custom"), aDlg.GetColor());
		m_cmb_font_colour.SetCurSel(nIndex);
		SetModified();
	}
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::ClearSettings()
{
	m_cmb_back_colour.SetCurSel(-1);
	m_cmb_font_name.SetCurSel(-1);
	m_cmb_font_sizes.SetCurSel(-1);
	m_cmb_font_colour.SetCurSel(-1);
	m_cmb_highlight_colour.SetCurSel(-1);
}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Called when combo box is changed.  It sets the modified  //
//				: flag to TRUE so user can be requested to save changes    //
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::OnCbnSelchangeCmbColour()
{
	SetModified();
}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Called when combo box is changed.  It sets the modified  //
//				: flag to TRUE so user can be requested to save changes    //
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::OnCbnSelchangeCmbFontName()
{
	SetModified();
}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Called when combo box is changed.  It sets the modified  //
//				: flag to TRUE so user can be requested to save changes    //
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::OnCbnSelchangeCmbFontColour()
{
	SetModified();
}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Called when combo box is changed.  It sets the modified  //
//				: flag to TRUE so user can be requested to save changes    //
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::OnCbnSelchangeCmbFontSizes()
{
	SetModified();
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::SaveSettings()	
{
	SaveButtonSettings();

}

/////////////////////////////////////////////////////////////////////////////
// DESCRIPTION	: Stores the changes to the button font settings.		   //
/////////////////////////////////////////////////////////////////////////////

void CWordSettings::SaveButtonSettings()
{
	CString szFontName = _T("");
	CString szFontSize = _T("");

	m_Settings->SetColourSetting(LABEL_BACKGROUND, m_cmb_back_colour.GetSelectedColorValue());
	m_cmb_font_name.GetLBText(m_cmb_font_name.GetCurSel(), szFontName);
	m_Settings->SetSetting(LABEL_FONT_NAME, szFontName);
	m_Settings->SetColourSetting(LABEL_FOREGROUND, m_cmb_font_colour.GetSelectedColorValue());
	m_cmb_font_sizes.GetLBText(m_cmb_font_sizes.GetCurSel(), szFontSize);
	m_Settings->SetSetting(LABEL_FONT_SIZE, szFontSize);
	m_Settings->SetColourSetting(HIGHLIGHT_COLOUR, m_cmb_highlight_colour.GetSelectedColorValue());

	m_Settings->StoreSettings();
}

void CWordSettings::OnBnClickedBtnCustomHighlightColour()
{
	CColorDialog aDlg;

	if(aDlg.DoModal() == IDOK)
	{
		// TODO : Add String to string table
		// Add the colour and set it to be current selection
		COLORREF colour = aDlg.GetColor();
		int nIndex = m_cmb_font_colour.AddColor(_T("Custom"), colour);
		m_cmb_highlight_colour.SetCurSel(nIndex);
		SetModified();
	}
}

void CWordSettings::OnCbnSelchangeCmbHighlightColour()
{
	SetModified();
}

void CWordSettings::OnOK()
{
	if (m_bModified)
	{
		SaveSettings();
		SetModified(FALSE);
	}
}
